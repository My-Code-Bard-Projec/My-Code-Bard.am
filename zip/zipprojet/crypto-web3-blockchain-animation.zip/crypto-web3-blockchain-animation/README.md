# crypto web3 blockchain animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/dok/pen/VBgPYO](https://codepen.io/dok/pen/VBgPYO).

only did the animation - for a bitcoin/crypto thingy site
