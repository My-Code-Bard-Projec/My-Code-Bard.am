 
Look mah' no JS!!!!

I wanted to illustrated CSS transitions with only transitions on the left and CSS animations on the right for one of my talk. The SVG was created using Adobe Illustrator Beta.

If you want to see each one on their own: - the transition day/night only: https://codepen.io/stephaniewalter/pen/yLObjRW - the animation only https://codepen.io/stephaniewalter/pen/vYGmrLR

 